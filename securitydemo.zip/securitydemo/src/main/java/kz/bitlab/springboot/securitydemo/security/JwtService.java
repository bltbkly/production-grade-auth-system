package kz.bitlab.springboot.securitydemo.security;

import io.jsonwebtoken.Claims;
import io.jsonwebtoken.Jwts;
import io.jsonwebtoken.security.Keys;
import java.nio.charset.StandardCharsets;
import java.time.Instant;
import java.time.temporal.ChronoUnit;
import java.util.Date;
import java.util.function.Function;
import javax.crypto.SecretKey;
import kz.bitlab.springboot.securitydemo.config.SecurityProperties;
import kz.bitlab.springboot.securitydemo.models.User;
import org.springframework.stereotype.Service;

@Service
public class JwtService {

	private final SecretKey key;
	private final SecurityProperties securityProperties;

	public JwtService(SecurityProperties securityProperties) {
		this.securityProperties = securityProperties;
		this.key = Keys.hmacShaKeyFor(securityProperties.getJwt().getSecret()
				.getBytes(StandardCharsets.UTF_8));
	}

	public String generateAccessToken(User user) {
		Instant now = Instant.now();
		Instant exp = now.plus(securityProperties.getJwt().getAccessTokenMinutes(), ChronoUnit.MINUTES);
		return Jwts.builder()
				.subject(user.getEmail())
				.claim("roles", user.getAuthorities().stream().map(a -> a.getAuthority()).toList())
				.claim("type", "access")
				.issuedAt(Date.from(now))
				.expiration(Date.from(exp))
				.signWith(key)
				.compact();
	}

	public String generateRefreshToken(User user) {
		Instant now = Instant.now();
		Instant exp = now.plus(securityProperties.getJwt().getRefreshTokenDays(), ChronoUnit.DAYS);
		return Jwts.builder()
				.subject(user.getEmail())
				.claim("type", "refresh")
				.issuedAt(Date.from(now))
				.expiration(Date.from(exp))
				.signWith(key)
				.compact();
	}

	public String extractUsername(String token) {
		return extractClaim(token, Claims::getSubject);
	}

	public String extractType(String token) {
		return extractAllClaims(token).get("type", String.class);
	}

	public Instant extractExpiration(String token) {
		return extractAllClaims(token).getExpiration().toInstant();
	}

	public boolean isTokenValid(String token, User user, String expectedType) {
		String username = extractUsername(token);
		String type = extractType(token);
		return username.equals(user.getEmail()) && expectedType.equals(type) && !isTokenExpired(token);
	}

	private boolean isTokenExpired(String token) {
		return extractExpiration(token).isBefore(Instant.now());
	}

	private <T> T extractClaim(String token, Function<Claims, T> resolver) {
		return resolver.apply(extractAllClaims(token));
	}

	private Claims extractAllClaims(String token) {
		return Jwts.parser().verifyWith(key).build().parseSignedClaims(token).getPayload();
	}
}
