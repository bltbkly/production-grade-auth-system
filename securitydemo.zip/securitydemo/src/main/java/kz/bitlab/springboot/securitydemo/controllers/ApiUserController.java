package kz.bitlab.springboot.securitydemo.controllers;

import java.util.Map;
import kz.bitlab.springboot.securitydemo.models.User;
import org.springframework.security.core.Authentication;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RestController;

@RestController
@RequestMapping("/api/users")
public class ApiUserController {

	@GetMapping("/me")
	public Map<String, Object> me(Authentication authentication) {
		User user = (User) authentication.getPrincipal();
		return Map.of(
				"email", user.getEmail(),
				"fullName", user.getFullName(),
				"roles", user.getAuthorities().stream().map(a -> a.getAuthority()).toList());
	}
}
