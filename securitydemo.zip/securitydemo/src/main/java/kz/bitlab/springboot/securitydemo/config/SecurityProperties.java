package kz.bitlab.springboot.securitydemo.config;

import lombok.Getter;
import lombok.Setter;
import org.springframework.boot.context.properties.ConfigurationProperties;
import org.springframework.stereotype.Component;

@Component
@ConfigurationProperties(prefix = "app.security")
@Getter
@Setter
public class SecurityProperties {

	private Jwt jwt = new Jwt();
	private Password password = new Password();
	private Lock lock = new Lock();
	private RateLimit rateLimit = new RateLimit();

	@Getter
	@Setter
	public static class Jwt {
		private String secret = "change-this-default-secret-to-long-random-key-for-production";
		private long accessTokenMinutes = 15;
		private long refreshTokenDays = 7;
	}

	@Getter
	@Setter
	public static class Password {
		private int minLength = 12;
		private boolean requireUppercase = true;
		private boolean requireLowercase = true;
		private boolean requireDigit = true;
		private boolean requireSpecial = true;
	}

	@Getter
	@Setter
	public static class Lock {
		private int maxFailedAttempts = 5;
		private long durationMinutes = 15;
	}

	@Getter
	@Setter
	public static class RateLimit {
		private int maxRequests = 20;
		private long windowSeconds = 60;
	}
}
