package kz.bitlab.springboot.securitydemo.services.impl;

import java.util.ArrayList;
import java.time.Instant;
import java.time.temporal.ChronoUnit;
import java.util.List;
import java.util.Objects;
import kz.bitlab.springboot.securitydemo.config.SecurityProperties;
import kz.bitlab.springboot.securitydemo.models.Permission;
import kz.bitlab.springboot.securitydemo.models.User;
import kz.bitlab.springboot.securitydemo.repositories.PermissionRepository;
import kz.bitlab.springboot.securitydemo.repositories.UserRepository;
import kz.bitlab.springboot.securitydemo.security.PasswordPolicyValidator;
import kz.bitlab.springboot.securitydemo.services.UserService;
import lombok.RequiredArgsConstructor;
import org.springframework.security.authentication.AnonymousAuthenticationToken;
import org.springframework.security.authentication.LockedException;
import org.springframework.security.core.Authentication;
import org.springframework.security.core.context.SecurityContextHolder;
import org.springframework.security.core.userdetails.UserDetails;
import org.springframework.security.core.userdetails.UsernameNotFoundException;
import org.springframework.security.crypto.password.PasswordEncoder;
import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Transactional;

@Service
@RequiredArgsConstructor
public class UserServiceImpl implements UserService {

	private final UserRepository userRepository;
	private final PermissionRepository permissionRepository;
	private final PasswordEncoder passwordEncoder;
	private final SecurityProperties securityProperties;
	private final PasswordPolicyValidator passwordPolicyValidator;

	@Override
	public UserDetails loadUserByUsername(String username) throws UsernameNotFoundException {
		User user = userRepository.findByEmail(username);
		if (Objects.nonNull(user)) {
			if (!user.isAccountNonLocked()) {
				throw new LockedException("Account locked");
			}
			return user;
		}
		throw new UsernameNotFoundException("User Not Found");
	}

	private User getCurrentUser() {
		Authentication authentication = SecurityContextHolder.getContext().getAuthentication();
		if (authentication != null && !(authentication instanceof AnonymousAuthenticationToken)) {
			return (User) authentication.getPrincipal();
		}
		return null;
	}

	@Override
	@Transactional
	public Boolean signUp(String email, String password, String repeatPassword, String fullName) {
		User existing = userRepository.findByEmail(email);
		if (Objects.nonNull(existing)) {
			return null;
		}
		if (!password.equals(repeatPassword)) {
			return false;
		}
		if (!passwordPolicyValidator.isValid(password)) {
			return false;
		}
		Permission userRole = permissionRepository.findByPermission("ROLE_USER");
		if (userRole == null) {
			throw new IllegalStateException("ROLE_USER is not seeded");
		}
		List<Permission> roles = new ArrayList<>();
		roles.add(userRole);
		User newUser = new User();
		newUser.setEmail(email);
		newUser.setPassword(passwordEncoder.encode(password));
		newUser.setFullName(fullName);
		newUser.setRoles(roles);
		userRepository.save(newUser);
		return true;
	}

	@Override
	@Transactional
	public Boolean updatePassword(String oldPassword, String newPassword, String repeatNewPassword) {
		User currentUser = getCurrentUser();
		if (Objects.isNull(currentUser)) {
			return null;
		}
		if (!passwordEncoder.matches(oldPassword, currentUser.getPassword())) {
			return null;
		}
		if (!newPassword.equals(repeatNewPassword)) {
			return false;
		}
		if (!passwordPolicyValidator.isValid(newPassword)) {
			return false;
		}
		currentUser.setPassword(passwordEncoder.encode(newPassword));
		userRepository.save(currentUser);
		return true;
	}

	@Override
	@Transactional(readOnly = true)
	public List<User> getAllUsers() {
		return userRepository.findAll();
	}

	@Override
	@Transactional
	public void deleteUserById(Long id) {
		userRepository.deleteById(id);
	}

	@Override
	@Transactional
	public void processFailedAttempt(String email) {
		User user = userRepository.findByEmail(email);
		if (user == null) {
			return;
		}
		int nextAttempts = user.getFailedLoginAttempts() == null ? 1 : user.getFailedLoginAttempts() + 1;
		user.setFailedLoginAttempts(nextAttempts);
		if (nextAttempts >= securityProperties.getLock().getMaxFailedAttempts()) {
			user.setLockUntil(Instant.now().plus(securityProperties.getLock().getDurationMinutes(), ChronoUnit.MINUTES));
			user.setFailedLoginAttempts(0);
		}
		userRepository.save(user);
	}

	@Override
	@Transactional
	public void resetFailedAttempts(User user) {
		user.setFailedLoginAttempts(0);
		user.setLockUntil(null);
		userRepository.save(user);
	}
}
