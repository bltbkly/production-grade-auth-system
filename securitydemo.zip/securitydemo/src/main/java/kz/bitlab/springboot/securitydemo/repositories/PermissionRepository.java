package kz.bitlab.springboot.securitydemo.repositories;

import kz.bitlab.springboot.securitydemo.models.Permission;
import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.stereotype.Repository;

@Repository
public interface PermissionRepository extends JpaRepository<Permission, Long> {

	Permission findByPermission(String permission);
}
