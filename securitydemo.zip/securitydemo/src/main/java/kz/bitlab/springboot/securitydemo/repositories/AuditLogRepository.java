package kz.bitlab.springboot.securitydemo.repositories;

import kz.bitlab.springboot.securitydemo.models.AuditLog;
import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.stereotype.Repository;

@Repository
public interface AuditLogRepository extends JpaRepository<AuditLog, Long> {
}
