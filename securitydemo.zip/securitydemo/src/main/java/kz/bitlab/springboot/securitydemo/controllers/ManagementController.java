package kz.bitlab.springboot.securitydemo.controllers;

import kz.bitlab.springboot.securitydemo.services.PostService;
import kz.bitlab.springboot.securitydemo.services.UserService;
import jakarta.validation.constraints.NotBlank;
import jakarta.validation.constraints.Size;
import lombok.RequiredArgsConstructor;
import org.springframework.security.access.prepost.PreAuthorize;
import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.validation.annotation.Validated;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestParam;

@Controller
@Validated
@RequiredArgsConstructor
public class ManagementController {

	private final UserService userService;
	private final PostService postService;

	@GetMapping("/posts")
	@PreAuthorize("hasAnyAuthority('ROLE_MANAGER','ROLE_ADMIN')")
	public String postsPage(Model model, @RequestParam(required = false) String q) {
		if (q != null && !q.isBlank()) {
			model.addAttribute("posts", postService.searchByName(q));
		} else {
			model.addAttribute("posts", postService.getAllPosts());
		}
		model.addAttribute("query", q == null ? "" : q);
		return "posts";
	}

	@PostMapping("/posts/create")
	@PreAuthorize("hasAnyAuthority('ROLE_MANAGER','ROLE_ADMIN')")
	public String createPost(
			@RequestParam @NotBlank @Size(max = 200) String name,
			@RequestParam @NotBlank @Size(max = 5000) String content) {
		postService.createPost(name, content);
		return "redirect:/posts";
	}

	@GetMapping("/users")
	@PreAuthorize("hasAuthority('ROLE_ADMIN')")
	public String usersPage(Model model) {
		model.addAttribute("users", userService.getAllUsers());
		return "users";
	}

	@PostMapping("/users/{id}/delete")
	@PreAuthorize("hasAuthority('ROLE_ADMIN')")
	public String deleteUser(@PathVariable Long id) {
		userService.deleteUserById(id);
		return "redirect:/users";
	}
}
