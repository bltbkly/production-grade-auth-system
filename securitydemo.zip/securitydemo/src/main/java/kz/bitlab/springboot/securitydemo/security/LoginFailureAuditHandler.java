package kz.bitlab.springboot.securitydemo.security;

import jakarta.servlet.ServletException;
import jakarta.servlet.http.HttpServletRequest;
import jakarta.servlet.http.HttpServletResponse;
import java.io.IOException;
import kz.bitlab.springboot.securitydemo.services.UserService;
import lombok.RequiredArgsConstructor;
import org.springframework.security.authentication.BadCredentialsException;
import org.springframework.security.authentication.LockedException;
import org.springframework.security.core.AuthenticationException;
import org.springframework.security.web.authentication.SimpleUrlAuthenticationFailureHandler;
import org.springframework.stereotype.Component;

@Component
@RequiredArgsConstructor
public class LoginFailureAuditHandler extends SimpleUrlAuthenticationFailureHandler {

	private final UserService userService;
	private final AuditService auditService;

	@Override
	public void onAuthenticationFailure(
			HttpServletRequest request, HttpServletResponse response, AuthenticationException exception)
			throws IOException, ServletException {
		String email = request.getParameter("user_email");
		if (email != null) {
			userService.processFailedAttempt(email);
			auditService.log("FORM_LOGIN_FAILURE", email, request, "Credentials rejected");
		}
		if (exception instanceof LockedException) {
			setDefaultFailureUrl("/sign-in?locked");
		} else if (exception instanceof BadCredentialsException) {
			setDefaultFailureUrl("/sign-in?error");
		}
		super.onAuthenticationFailure(request, response, exception);
	}
}
