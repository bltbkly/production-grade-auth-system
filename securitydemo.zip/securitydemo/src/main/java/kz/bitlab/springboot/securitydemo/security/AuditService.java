package kz.bitlab.springboot.securitydemo.security;

import jakarta.servlet.http.HttpServletRequest;
import java.time.Instant;
import kz.bitlab.springboot.securitydemo.models.AuditLog;
import kz.bitlab.springboot.securitydemo.repositories.AuditLogRepository;
import lombok.RequiredArgsConstructor;
import lombok.extern.slf4j.Slf4j;
import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Transactional;

@Service
@RequiredArgsConstructor
@Slf4j
public class AuditService {

	private final AuditLogRepository auditLogRepository;

	@Transactional
	public void log(String eventType, String principal, HttpServletRequest request, String details) {
		String ip = request == null ? "n/a" : request.getRemoteAddr();
		String ua = request == null ? "n/a" : request.getHeader("User-Agent");
		log.info("AUDIT event={} principal={} ip={} details={}", eventType, principal, ip, details);

		AuditLog auditLog = new AuditLog();
		auditLog.setEventType(eventType);
		auditLog.setPrincipal(principal);
		auditLog.setIpAddress(ip);
		auditLog.setUserAgent(ua);
		auditLog.setDetails(details);
		auditLog.setCreatedAt(Instant.now());
		auditLogRepository.save(auditLog);
	}
}
