package kz.bitlab.springboot.securitydemo.security;

import jakarta.servlet.ServletException;
import jakarta.servlet.http.HttpServletRequest;
import jakarta.servlet.http.HttpServletResponse;
import java.io.IOException;
import kz.bitlab.springboot.securitydemo.models.User;
import kz.bitlab.springboot.securitydemo.services.UserService;
import lombok.RequiredArgsConstructor;
import org.springframework.security.core.Authentication;
import org.springframework.security.web.authentication.SimpleUrlAuthenticationSuccessHandler;
import org.springframework.stereotype.Component;

@Component
@RequiredArgsConstructor
public class LoginSuccessAuditHandler extends SimpleUrlAuthenticationSuccessHandler {

	private final UserService userService;
	private final AuditService auditService;

	@Override
	public void onAuthenticationSuccess(HttpServletRequest request, HttpServletResponse response, Authentication authentication)
			throws IOException, ServletException {
		User user = (User) authentication.getPrincipal();
		userService.resetFailedAttempts(user);
		auditService.log("FORM_LOGIN_SUCCESS", user.getEmail(), request, "Interactive login success");
		super.onAuthenticationSuccess(request, response, authentication);
	}
}
