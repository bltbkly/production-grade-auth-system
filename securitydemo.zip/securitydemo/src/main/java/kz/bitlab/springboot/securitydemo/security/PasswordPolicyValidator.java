package kz.bitlab.springboot.securitydemo.security;

import kz.bitlab.springboot.securitydemo.config.SecurityProperties;
import org.springframework.stereotype.Component;

@Component
public class PasswordPolicyValidator {

	private final SecurityProperties securityProperties;

	public PasswordPolicyValidator(SecurityProperties securityProperties) {
		this.securityProperties = securityProperties;
	}

	public boolean isValid(String password) {
		if (password == null) {
			return false;
		}
		SecurityProperties.Password p = securityProperties.getPassword();
		if (password.length() < p.getMinLength()) {
			return false;
		}
		if (p.isRequireUppercase() && password.chars().noneMatch(Character::isUpperCase)) {
			return false;
		}
		if (p.isRequireLowercase() && password.chars().noneMatch(Character::isLowerCase)) {
			return false;
		}
		if (p.isRequireDigit() && password.chars().noneMatch(Character::isDigit)) {
			return false;
		}
		if (p.isRequireSpecial() && password.chars().noneMatch(ch -> !Character.isLetterOrDigit(ch))) {
			return false;
		}
		return true;
	}
}
