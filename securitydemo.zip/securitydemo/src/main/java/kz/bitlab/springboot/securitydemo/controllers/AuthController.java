package kz.bitlab.springboot.securitydemo.controllers;

import jakarta.servlet.http.HttpServletRequest;
import jakarta.validation.Valid;
import kz.bitlab.springboot.securitydemo.dto.AuthRequest;
import kz.bitlab.springboot.securitydemo.dto.AuthResponse;
import kz.bitlab.springboot.securitydemo.dto.RefreshTokenRequest;
import kz.bitlab.springboot.securitydemo.dto.RegisterRequest;
import kz.bitlab.springboot.securitydemo.services.AuthService;
import lombok.RequiredArgsConstructor;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RestController;

@RestController
@RequestMapping("/api/auth")
@RequiredArgsConstructor
public class AuthController {

	private final AuthService authService;

	@PostMapping("/register")
	public ResponseEntity<Void> register(@Valid @RequestBody RegisterRequest request, HttpServletRequest servletRequest) {
		authService.register(request, servletRequest);
		return ResponseEntity.ok().build();
	}

	@PostMapping("/login")
	public ResponseEntity<AuthResponse> login(@Valid @RequestBody AuthRequest request, HttpServletRequest servletRequest) {
		return ResponseEntity.ok(authService.login(request, servletRequest));
	}

	@PostMapping("/refresh")
	public ResponseEntity<AuthResponse> refresh(
			@Valid @RequestBody RefreshTokenRequest request, HttpServletRequest servletRequest) {
		return ResponseEntity.ok(authService.refresh(request, servletRequest));
	}

	@PostMapping("/logout")
	public ResponseEntity<Void> logout(
			@Valid @RequestBody RefreshTokenRequest request, HttpServletRequest servletRequest) {
		authService.logout(request, servletRequest);
		return ResponseEntity.noContent().build();
	}
}
