package kz.bitlab.springboot.securitydemo.models;

import jakarta.persistence.Column;
import jakarta.persistence.Entity;
import jakarta.persistence.Table;
import java.time.Instant;
import lombok.Getter;
import lombok.Setter;

@Entity
@Table(name = "t_posts")
@Getter
@Setter
public class Post extends BaseEntity {

	@Column(nullable = false)
	private String name;

	@Column(length = 4000)
	private String content;

	@Column(nullable = false)
	private Instant postedAt;
}
