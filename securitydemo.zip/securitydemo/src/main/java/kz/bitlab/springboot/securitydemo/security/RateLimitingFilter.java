package kz.bitlab.springboot.securitydemo.security;

import jakarta.servlet.FilterChain;
import jakarta.servlet.ServletException;
import jakarta.servlet.http.HttpServletRequest;
import jakarta.servlet.http.HttpServletResponse;
import java.io.IOException;
import java.time.Instant;
import java.util.Map;
import java.util.concurrent.ConcurrentHashMap;
import kz.bitlab.springboot.securitydemo.config.SecurityProperties;
import org.springframework.http.MediaType;
import org.springframework.stereotype.Component;
import org.springframework.web.filter.OncePerRequestFilter;

@Component
public class RateLimitingFilter extends OncePerRequestFilter {

	private final SecurityProperties securityProperties;
	private final Map<String, SlidingWindowCounter> counters = new ConcurrentHashMap<>();

	public RateLimitingFilter(SecurityProperties securityProperties) {
		this.securityProperties = securityProperties;
	}

	@Override
	protected boolean shouldNotFilter(HttpServletRequest request) {
		String uri = request.getRequestURI();
		return !uri.startsWith("/api/auth/login")
				&& !uri.startsWith("/api/auth/refresh")
				&& !uri.startsWith("/entering");
	}

	@Override
	protected void doFilterInternal(HttpServletRequest request, HttpServletResponse response, FilterChain filterChain)
			throws ServletException, IOException {
		String key = request.getRemoteAddr() + ":" + request.getRequestURI();
		SlidingWindowCounter counter = counters.computeIfAbsent(key, k -> new SlidingWindowCounter());
		if (!counter.tryAcquire(securityProperties.getRateLimit().getMaxRequests(),
				securityProperties.getRateLimit().getWindowSeconds())) {
			response.setStatus(429);
			response.setContentType(MediaType.APPLICATION_JSON_VALUE);
			response.getWriter().write("{\"error\":\"Too many requests. Please try again later.\"}");
			return;
		}
		filterChain.doFilter(request, response);
	}

	private static final class SlidingWindowCounter {
		private long windowStart = Instant.now().getEpochSecond();
		private int count = 0;

		private synchronized boolean tryAcquire(int maxRequests, long windowSeconds) {
			long now = Instant.now().getEpochSecond();
			if (now - windowStart >= windowSeconds) {
				windowStart = now;
				count = 0;
			}
			if (count >= maxRequests) {
				return false;
			}
			count++;
			return true;
		}
	}
}
