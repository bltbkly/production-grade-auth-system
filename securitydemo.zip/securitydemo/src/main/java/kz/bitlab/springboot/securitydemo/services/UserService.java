package kz.bitlab.springboot.securitydemo.services;

import java.util.List;
import kz.bitlab.springboot.securitydemo.models.User;
import org.springframework.security.core.userdetails.UserDetailsService;

public interface UserService extends UserDetailsService {

	Boolean signUp(String email, String password, String repeatPassword, String fullName);

	Boolean updatePassword(String oldPassword, String newPassword, String repeatNewPassword);

	List<User> getAllUsers();

	void deleteUserById(Long id);

	void processFailedAttempt(String email);

	void resetFailedAttempts(User user);
}
