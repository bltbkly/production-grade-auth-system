package kz.bitlab.springboot.securitydemo.controllers;

import org.springframework.security.access.prepost.PreAuthorize;
import org.springframework.stereotype.Controller;
import org.springframework.web.bind.annotation.GetMapping;

@Controller
public class HomeController {

	@GetMapping({"/", "/index"})
	public String homePage() {
		return "index";
	}

	@GetMapping("/sign-in")
	@PreAuthorize("isAnonymous()")
	public String loginPage() {
		return "sign-in";
	}

	@GetMapping("/profile")
	@PreAuthorize("isAuthenticated()")
	public String profile() {
		return "profile";
	}

	@GetMapping("/forbidden")
	public String forbidden() {
		return "forbidden";
	}
}
