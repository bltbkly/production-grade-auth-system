package kz.bitlab.springboot.securitydemo.controllers;

import kz.bitlab.springboot.securitydemo.services.UserService;
import jakarta.validation.constraints.Email;
import jakarta.validation.constraints.NotBlank;
import jakarta.validation.constraints.Size;
import lombok.RequiredArgsConstructor;
import org.springframework.security.access.prepost.PreAuthorize;
import org.springframework.stereotype.Controller;
import org.springframework.validation.annotation.Validated;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestParam;

@Controller
@Validated
@RequiredArgsConstructor
public class UserController {

	private final UserService userService;

	@GetMapping("/sign-up")
	@PreAuthorize("isAnonymous()")
	public String signUpPage() {
		return "sign-up";
	}

	@PostMapping("/registration")
	@PreAuthorize("isAnonymous()")
	public String registration(
			@RequestParam(name = "user_email") @NotBlank @Email String email,
			@RequestParam(name = "user_password") @NotBlank String password,
			@RequestParam(name = "user_repeat_password") @NotBlank String repeatPassword,
			@RequestParam(name = "user_full_name") @NotBlank @Size(min = 2, max = 120) String fullName) {
		Boolean result = userService.signUp(email, password, repeatPassword, fullName);
		if (result != null) {
			if (result) {
				return "redirect:/sign-up?success";
			}
			return "redirect:/sign-up?passwordError";
		}
		return "redirect:/sign-up?emailError";
	}

	@GetMapping("/change-password")
	@PreAuthorize("isAuthenticated()")
	public String changePasswordPage() {
		return "change-password";
	}

	@PostMapping("/save-password")
	@PreAuthorize("isAuthenticated()")
	public String savePassword(
			@RequestParam(name = "user_old_password") @NotBlank String oldPassword,
			@RequestParam(name = "user_new_password") @NotBlank String newPassword,
			@RequestParam(name = "user_repeat_new_password") @NotBlank String repeatNewPassword) {
		Boolean result = userService.updatePassword(oldPassword, newPassword, repeatNewPassword);
		if (result != null) {
			if (result) {
				return "redirect:/change-password?success";
			}
			return "redirect:/change-password?newPasswordError";
		}
		return "redirect:/change-password?oldPasswordError";
	}
}
