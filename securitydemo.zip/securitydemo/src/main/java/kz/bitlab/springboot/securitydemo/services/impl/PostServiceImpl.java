package kz.bitlab.springboot.securitydemo.services.impl;

import java.time.Instant;
import java.util.List;
import kz.bitlab.springboot.securitydemo.models.Post;
import kz.bitlab.springboot.securitydemo.repositories.PostRepository;
import kz.bitlab.springboot.securitydemo.services.PostService;
import lombok.RequiredArgsConstructor;
import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Transactional;

@Service
@RequiredArgsConstructor
public class PostServiceImpl implements PostService {

	private final PostRepository postRepository;

	@Override
	@Transactional(readOnly = true)
	public List<Post> getAllPosts() {
		return postRepository.findAll();
	}

	@Override
	@Transactional(readOnly = true)
	public List<Post> searchByName(String query) {
		if (query == null || query.isBlank()) {
			return getAllPosts();
		}
		return postRepository.searchByNameContaining(query.trim());
	}

	@Override
	@Transactional
	public Post createPost(String name, String content) {
		Post post = new Post();
		post.setName(name);
		post.setContent(content);
		post.setPostedAt(Instant.now());
		return postRepository.save(post);
	}
}
