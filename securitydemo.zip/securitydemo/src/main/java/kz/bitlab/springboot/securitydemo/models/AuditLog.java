package kz.bitlab.springboot.securitydemo.models;

import jakarta.persistence.Column;
import jakarta.persistence.Entity;
import jakarta.persistence.Table;
import java.time.Instant;
import lombok.Getter;
import lombok.Setter;

@Entity
@Table(name = "t_audit_logs")
@Getter
@Setter
public class AuditLog extends BaseEntity {

	@Column(name = "event_type", nullable = false)
	private String eventType;

	@Column(name = "principal")
	private String principal;

	@Column(name = "ip_address")
	private String ipAddress;

	@Column(name = "user_agent", length = 1024)
	private String userAgent;

	@Column(name = "details", length = 2048)
	private String details;

	@Column(name = "created_at", nullable = false)
	private Instant createdAt;
}
