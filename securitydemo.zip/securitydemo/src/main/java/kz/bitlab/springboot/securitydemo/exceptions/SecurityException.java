package kz.bitlab.springboot.securitydemo.exceptions;

import org.springframework.http.HttpStatus;

public class SecurityException extends RuntimeException {

	private final HttpStatus status;

	public SecurityException(HttpStatus status, String message) {
		super(message);
		this.status = status;
	}

	public HttpStatus getStatus() {
		return status;
	}
}
