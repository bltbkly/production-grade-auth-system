package kz.bitlab.springboot.securitydemo.config;

import java.time.Instant;
import java.util.ArrayList;
import java.util.List;
import kz.bitlab.springboot.securitydemo.models.Permission;
import kz.bitlab.springboot.securitydemo.models.Post;
import kz.bitlab.springboot.securitydemo.models.User;
import kz.bitlab.springboot.securitydemo.repositories.PermissionRepository;
import kz.bitlab.springboot.securitydemo.repositories.PostRepository;
import kz.bitlab.springboot.securitydemo.repositories.UserRepository;
import lombok.RequiredArgsConstructor;
import org.springframework.boot.CommandLineRunner;
import org.springframework.context.annotation.Profile;
import org.springframework.security.crypto.password.PasswordEncoder;
import org.springframework.stereotype.Component;

@Component
@Profile("!test")
@RequiredArgsConstructor
public class DataInitializer implements CommandLineRunner {

	private final PermissionRepository permissionRepository;
	private final UserRepository userRepository;
	private final PostRepository postRepository;
	private final PasswordEncoder passwordEncoder;

	@Override
	public void run(String... args) {
		if (permissionRepository.count() > 0) {
			return;
		}
		Permission roleUser = savePermission("ROLE_USER");
		Permission roleManager = savePermission("ROLE_MANAGER");
		Permission roleAdmin = savePermission("ROLE_ADMIN");

		saveUser("user@example.com", "user123", "Demo User", List.of(roleUser));
		saveUser("manager@example.com", "manager123", "Demo Manager", List.of(roleUser, roleManager));
		saveUser("admin@example.com", "admin123", "Demo Admin", List.of(roleUser, roleManager, roleAdmin));

		Post welcome = new Post();
		welcome.setName("Welcome");
		welcome.setContent("Sample content for managers and admins.");
		welcome.setPostedAt(Instant.now());
		postRepository.save(welcome);
	}

	private Permission savePermission(String code) {
		Permission p = new Permission();
		p.setPermission(code);
		return permissionRepository.save(p);
	}

	private void saveUser(String email, String rawPassword, String fullName, List<Permission> roles) {
		User u = new User();
		u.setEmail(email);
		u.setPassword(passwordEncoder.encode(rawPassword));
		u.setFullName(fullName);
		u.setRoles(new ArrayList<>(roles));
		userRepository.save(u);
	}
}
