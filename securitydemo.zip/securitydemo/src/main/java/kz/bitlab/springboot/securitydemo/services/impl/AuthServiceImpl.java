package kz.bitlab.springboot.securitydemo.services.impl;

import jakarta.servlet.http.HttpServletRequest;
import java.util.List;
import kz.bitlab.springboot.securitydemo.config.SecurityProperties;
import kz.bitlab.springboot.securitydemo.dto.AuthRequest;
import kz.bitlab.springboot.securitydemo.dto.AuthResponse;
import kz.bitlab.springboot.securitydemo.dto.RefreshTokenRequest;
import kz.bitlab.springboot.securitydemo.dto.RegisterRequest;
import kz.bitlab.springboot.securitydemo.exceptions.SecurityException;
import kz.bitlab.springboot.securitydemo.models.RefreshToken;
import kz.bitlab.springboot.securitydemo.models.User;
import kz.bitlab.springboot.securitydemo.repositories.RefreshTokenRepository;
import kz.bitlab.springboot.securitydemo.repositories.UserRepository;
import kz.bitlab.springboot.securitydemo.security.AuditService;
import kz.bitlab.springboot.securitydemo.security.JwtService;
import kz.bitlab.springboot.securitydemo.services.AuthService;
import kz.bitlab.springboot.securitydemo.services.UserService;
import lombok.RequiredArgsConstructor;
import org.springframework.http.HttpStatus;
import org.springframework.security.authentication.AuthenticationManager;
import org.springframework.security.authentication.BadCredentialsException;
import org.springframework.security.authentication.LockedException;
import org.springframework.security.authentication.UsernamePasswordAuthenticationToken;
import org.springframework.security.core.Authentication;
import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Transactional;

@Service
@RequiredArgsConstructor
public class AuthServiceImpl implements AuthService {

	private final AuthenticationManager authenticationManager;
	private final UserRepository userRepository;
	private final UserService userService;
	private final JwtService jwtService;
	private final RefreshTokenRepository refreshTokenRepository;
	private final SecurityProperties securityProperties;
	private final AuditService auditService;

	@Override
	@Transactional
	public void register(RegisterRequest request, HttpServletRequest servletRequest) {
		Boolean created = userService.signUp(
				request.email(), request.password(), request.repeatPassword(), request.fullName());
		if (created == null) {
			throw new SecurityException(HttpStatus.CONFLICT, "User already exists");
		}
		if (!created) {
			throw new SecurityException(HttpStatus.BAD_REQUEST, "Registration data rejected");
		}
		auditService.log("REGISTER_SUCCESS", request.email(), servletRequest, "User registration");
	}

	@Override
	@Transactional
	public AuthResponse login(AuthRequest request, HttpServletRequest servletRequest) {
		User user = userRepository.findByEmail(request.email());
		if (user == null) {
			auditService.log("API_LOGIN_FAILURE", request.email(), servletRequest, "Unknown principal");
			throw new SecurityException(HttpStatus.UNAUTHORIZED, "Invalid credentials");
		}
		if (!user.isAccountNonLocked()) {
			throw new SecurityException(HttpStatus.LOCKED, "Account temporarily locked");
		}
		try {
			Authentication authentication = authenticationManager.authenticate(
					new UsernamePasswordAuthenticationToken(request.email(), request.password()));
			User authenticated = (User) authentication.getPrincipal();
			userService.resetFailedAttempts(authenticated);

			String accessToken = jwtService.generateAccessToken(authenticated);
			String refreshToken = jwtService.generateRefreshToken(authenticated);
			storeRefreshToken(authenticated, refreshToken);

			auditService.log("API_LOGIN_SUCCESS", authenticated.getEmail(), servletRequest, "JWT issued");
			return new AuthResponse(
					accessToken,
					refreshToken,
					"Bearer",
					securityProperties.getJwt().getAccessTokenMinutes() * 60);
		} catch (LockedException ex) {
			throw new SecurityException(HttpStatus.LOCKED, "Account temporarily locked");
		} catch (BadCredentialsException ex) {
			userService.processFailedAttempt(request.email());
			auditService.log("API_LOGIN_FAILURE", request.email(), servletRequest, "Bad credentials");
			throw new SecurityException(HttpStatus.UNAUTHORIZED, "Invalid credentials");
		}
	}

	@Override
	@Transactional
	public AuthResponse refresh(RefreshTokenRequest request, HttpServletRequest servletRequest) {
		RefreshToken stored = refreshTokenRepository.findByToken(request.refreshToken())
				.orElseThrow(() -> new SecurityException(HttpStatus.UNAUTHORIZED, "Invalid refresh token"));
		if (stored.isRevoked()) {
			throw new SecurityException(HttpStatus.UNAUTHORIZED, "Invalid refresh token");
		}
		User user = stored.getUser();
		if (!jwtService.isTokenValid(stored.getToken(), user, "refresh")) {
			stored.setRevoked(true);
			refreshTokenRepository.save(stored);
			throw new SecurityException(HttpStatus.UNAUTHORIZED, "Refresh token expired");
		}
		stored.setRevoked(true);
		refreshTokenRepository.save(stored);

		String nextRefresh = jwtService.generateRefreshToken(user);
		storeRefreshToken(user, nextRefresh);
		String accessToken = jwtService.generateAccessToken(user);
		auditService.log("API_TOKEN_REFRESH", user.getEmail(), servletRequest, "Refresh rotation");
		return new AuthResponse(
				accessToken,
				nextRefresh,
				"Bearer",
				securityProperties.getJwt().getAccessTokenMinutes() * 60);
	}

	@Override
	@Transactional
	public void logout(RefreshTokenRequest request, HttpServletRequest servletRequest) {
		refreshTokenRepository.findByToken(request.refreshToken()).ifPresent(token -> {
			token.setRevoked(true);
			refreshTokenRepository.save(token);
			auditService.log("API_LOGOUT", token.getUser().getEmail(), servletRequest, "Refresh revoked");
		});
	}

	private void storeRefreshToken(User user, String refreshToken) {
		List<RefreshToken> existing = refreshTokenRepository.findAllByUserAndRevokedFalse(user);
		existing.forEach(token -> token.setRevoked(true));
		refreshTokenRepository.saveAll(existing);

		RefreshToken newToken = new RefreshToken();
		newToken.setUser(user);
		newToken.setToken(refreshToken);
		newToken.setExpiresAt(jwtService.extractExpiration(refreshToken));
		newToken.setRevoked(false);
		refreshTokenRepository.save(newToken);
	}
}
