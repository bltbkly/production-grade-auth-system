package kz.bitlab.springboot.securitydemo.models;

import jakarta.persistence.Column;
import jakarta.persistence.Entity;
import jakarta.persistence.Table;
import lombok.Getter;
import lombok.Setter;
import org.springframework.security.core.GrantedAuthority;

@Entity
@Table(name = "t_permissions")
@Getter
@Setter
public class Permission extends BaseEntity implements GrantedAuthority {

	@Column(name = "permission", nullable = false, unique = true)
	private String permission;

	@Override
	public String getAuthority() {
		return permission;
	}
}
