package kz.bitlab.springboot.securitydemo.repositories;

import java.util.List;
import java.util.Optional;
import kz.bitlab.springboot.securitydemo.models.RefreshToken;
import kz.bitlab.springboot.securitydemo.models.User;
import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.stereotype.Repository;

@Repository
public interface RefreshTokenRepository extends JpaRepository<RefreshToken, Long> {

	Optional<RefreshToken> findByToken(String token);

	List<RefreshToken> findAllByUserAndRevokedFalse(User user);
}
