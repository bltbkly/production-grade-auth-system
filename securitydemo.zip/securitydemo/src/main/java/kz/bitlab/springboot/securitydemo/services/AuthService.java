package kz.bitlab.springboot.securitydemo.services;

import jakarta.servlet.http.HttpServletRequest;
import kz.bitlab.springboot.securitydemo.dto.AuthRequest;
import kz.bitlab.springboot.securitydemo.dto.AuthResponse;
import kz.bitlab.springboot.securitydemo.dto.RefreshTokenRequest;
import kz.bitlab.springboot.securitydemo.dto.RegisterRequest;

public interface AuthService {

	void register(RegisterRequest request, HttpServletRequest servletRequest);

	AuthResponse login(AuthRequest request, HttpServletRequest servletRequest);

	AuthResponse refresh(RefreshTokenRequest request, HttpServletRequest servletRequest);

	void logout(RefreshTokenRequest request, HttpServletRequest servletRequest);
}
