package kz.bitlab.springboot.securitydemo.dto;

public record AuthResponse(
		String accessToken,
		String refreshToken,
		String tokenType,
		long accessTokenExpiresInSeconds) {
}
