package kz.bitlab.springboot.securitydemo.services;

import java.util.List;
import kz.bitlab.springboot.securitydemo.models.Post;

public interface PostService {

	List<Post> getAllPosts();

	List<Post> searchByName(String query);

	Post createPost(String name, String content);
}
