package kz.bitlab.springboot.securitydemo.repositories;

import java.util.List;
import kz.bitlab.springboot.securitydemo.models.Post;
import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.data.jpa.repository.Query;
import org.springframework.data.repository.query.Param;
import org.springframework.stereotype.Repository;

@Repository
public interface PostRepository extends JpaRepository<Post, Long> {

	@Query("SELECT p FROM Post p WHERE p.name LIKE CONCAT('%', :q, '%')")
	List<Post> searchByNameContaining(@Param("q") String q);
}
