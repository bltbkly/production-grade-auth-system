package kz.bitlab.springboot.securitydemo.dto;

import jakarta.validation.constraints.Email;
import jakarta.validation.constraints.NotBlank;
import jakarta.validation.constraints.Size;

public record RegisterRequest(
		@NotBlank @Email String email,
		@NotBlank @Size(min = 2, max = 120) String fullName,
		@NotBlank String password,
		@NotBlank String repeatPassword) {
}
