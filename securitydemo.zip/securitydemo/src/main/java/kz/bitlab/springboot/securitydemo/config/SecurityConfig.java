package kz.bitlab.springboot.securitydemo.config;

import kz.bitlab.springboot.securitydemo.services.UserService;
import kz.bitlab.springboot.securitydemo.security.JwtAuthenticationFilter;
import kz.bitlab.springboot.securitydemo.security.LoginFailureAuditHandler;
import kz.bitlab.springboot.securitydemo.security.LoginSuccessAuditHandler;
import kz.bitlab.springboot.securitydemo.security.RateLimitingFilter;
import lombok.RequiredArgsConstructor;
import org.springframework.context.annotation.Bean;
import org.springframework.context.annotation.Configuration;
import org.springframework.core.annotation.Order;
import org.springframework.http.HttpMethod;
import org.springframework.security.authentication.AuthenticationManager;
import org.springframework.security.authentication.dao.DaoAuthenticationProvider;
import org.springframework.security.config.annotation.authentication.configuration.AuthenticationConfiguration;
import org.springframework.security.config.annotation.method.configuration.EnableMethodSecurity;
import org.springframework.security.config.annotation.web.builders.HttpSecurity;
import org.springframework.security.config.annotation.web.configuration.EnableWebSecurity;
import org.springframework.security.config.annotation.web.configurers.HeadersConfigurer;
import org.springframework.security.config.http.SessionCreationPolicy;
import org.springframework.security.crypto.password.PasswordEncoder;
import org.springframework.security.web.authentication.UsernamePasswordAuthenticationFilter;
import org.springframework.security.web.SecurityFilterChain;

@Configuration
@EnableWebSecurity
@EnableMethodSecurity
@RequiredArgsConstructor
public class SecurityConfig {

	private final UserService userService;
	private final JwtAuthenticationFilter jwtAuthenticationFilter;
	private final RateLimitingFilter rateLimitingFilter;
	private final LoginSuccessAuditHandler loginSuccessAuditHandler;
	private final LoginFailureAuditHandler loginFailureAuditHandler;

	@Bean
	public DaoAuthenticationProvider authenticationProvider(PasswordEncoder passwordEncoder) {
		DaoAuthenticationProvider provider = new DaoAuthenticationProvider(userService);
		provider.setPasswordEncoder(passwordEncoder);
		return provider;
	}

	@Bean
	public AuthenticationManager authenticationManager(AuthenticationConfiguration configuration) throws Exception {
		return configuration.getAuthenticationManager();
	}

	@Bean
	@Order(1)
	public SecurityFilterChain apiFilterChain(HttpSecurity http, DaoAuthenticationProvider authenticationProvider)
			throws Exception {
		http.securityMatcher("/api/**")
				.authenticationProvider(authenticationProvider)
				.csrf(csrf -> csrf.disable())
				.sessionManagement(sm -> sm.sessionCreationPolicy(SessionCreationPolicy.STATELESS))
				.headers(headers -> headers
						.frameOptions(HeadersConfigurer.FrameOptionsConfig::deny)
						.httpStrictTransportSecurity(hsts -> hsts
								.includeSubDomains(true)
								.maxAgeInSeconds(31536000))
						.contentSecurityPolicy(csp -> csp.policyDirectives("default-src 'none'; frame-ancestors 'none'")))
				.authorizeHttpRequests(authorize -> authorize
						.requestMatchers("/api/auth/login", "/api/auth/register", "/api/auth/refresh").permitAll()
						.anyRequest().authenticated())
				.exceptionHandling(exception -> exception
						.accessDeniedHandler((request, response, ex) -> response.sendError(403, "Access denied"))
						.authenticationEntryPoint((request, response, ex) -> response.sendError(401, "Unauthorized")))
				.addFilterBefore(rateLimitingFilter, UsernamePasswordAuthenticationFilter.class)
				.addFilterBefore(jwtAuthenticationFilter, UsernamePasswordAuthenticationFilter.class);
		return http.build();
	}

	@Bean
	@Order(2)
	public SecurityFilterChain webFilterChain(HttpSecurity http, DaoAuthenticationProvider authenticationProvider)
			throws Exception {
		http.authenticationProvider(authenticationProvider)
				.headers(headers -> headers
						.frameOptions(HeadersConfigurer.FrameOptionsConfig::sameOrigin)
						.httpStrictTransportSecurity(hsts -> hsts
								.includeSubDomains(true)
								.maxAgeInSeconds(31536000))
						.contentSecurityPolicy(csp -> csp.policyDirectives(
								"default-src 'self'; script-src 'self'; style-src 'self' 'unsafe-inline'; object-src 'none'; frame-ancestors 'self'")))
				.csrf(csrf -> csrf.ignoringRequestMatchers("/h2-console/**"))
				.exceptionHandling(exception -> exception.accessDeniedPage("/forbidden"))
				.authorizeHttpRequests(authorize -> authorize
						.requestMatchers("/h2-console/**").permitAll()
						.requestMatchers("/css/**", "/js/**", "/favicon.ico", "/error", "/forbidden")
								.permitAll()
						.requestMatchers("/", "/index").permitAll()
						.requestMatchers("/sign-in", "/entering", "/sign-up", "/registration").anonymous()
						.requestMatchers("/sign-out", "/change-password", "/save-password", "/profile").authenticated()
						.requestMatchers(HttpMethod.POST, "/posts/create", "/users/*/delete", "/save-password")
						.authenticated()
						.requestMatchers("/users", "/users/**").hasAuthority("ROLE_ADMIN")
						.requestMatchers("/posts", "/posts/**")
								.hasAnyAuthority("ROLE_MANAGER", "ROLE_ADMIN")
						.anyRequest().denyAll())
				.formLogin(login -> login.loginProcessingUrl("/entering")
						.defaultSuccessUrl("/profile")
						.loginPage("/sign-in")
						.successHandler(loginSuccessAuditHandler)
						.failureHandler(loginFailureAuditHandler)
						.usernameParameter("user_email")
						.passwordParameter("user_password"))
				.logout(logout -> logout.logoutSuccessUrl("/sign-in?logout").logoutUrl("/sign-out"))
				.addFilterBefore(rateLimitingFilter, UsernamePasswordAuthenticationFilter.class);
		return http.build();
	}
}
