package kz.bitlab.springboot.securitydemo.security;

import static org.assertj.core.api.Assertions.assertThat;

import java.time.Instant;
import java.util.List;
import kz.bitlab.springboot.securitydemo.models.Post;
import kz.bitlab.springboot.securitydemo.repositories.PostRepository;
import org.junit.jupiter.api.BeforeEach;
import org.junit.jupiter.api.Test;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.boot.data.jpa.test.autoconfigure.DataJpaTest;
import org.springframework.test.context.ActiveProfiles;

@DataJpaTest
@ActiveProfiles("test")
class PostRepositoryParamBindingIT {

	@Autowired
	private PostRepository postRepository;

	@BeforeEach
	void clear() {
		postRepository.deleteAll();
	}

	@Test
	void likeSearchUsesBoundParameter_userInputCannotBreakJpqlStructure() {
		postRepository.save(post("Alpha"));
		postRepository.save(post("Beta"));
		postRepository.save(post("Gamma"));

		String injectionLikePayload = "Alpha' OR '1'='1";
		List<Post> hits = postRepository.searchByNameContaining(injectionLikePayload);

		assertThat(hits).isEmpty();
		assertThat(postRepository.findAll()).hasSize(3);
	}

	@Test
	void normalSearchStillFindsMatches() {
		postRepository.save(post("Hello world"));
		List<Post> hits = postRepository.searchByNameContaining("Hello");
		assertThat(hits).hasSize(1);
		assertThat(hits.getFirst().getName()).isEqualTo("Hello world");
	}

	private static Post post(String name) {
		Post p = new Post();
		p.setName(name);
		p.setContent("c");
		p.setPostedAt(Instant.now());
		return p;
	}
}
