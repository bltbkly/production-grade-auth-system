package kz.bitlab.springboot.securitydemo.security;

import static org.assertj.core.api.Assertions.assertThat;
import static org.springframework.security.test.web.servlet.request.SecurityMockMvcRequestPostProcessors.csrf;
import static org.springframework.security.test.web.servlet.request.SecurityMockMvcRequestPostProcessors.user;
import static org.springframework.test.web.servlet.request.MockMvcRequestBuilders.get;
import static org.springframework.test.web.servlet.request.MockMvcRequestBuilders.post;
import static org.springframework.test.web.servlet.result.MockMvcResultMatchers.redirectedUrl;
import static org.springframework.test.web.servlet.result.MockMvcResultMatchers.status;

import java.util.ArrayList;
import java.util.List;
import kz.bitlab.springboot.securitydemo.models.Permission;
import kz.bitlab.springboot.securitydemo.models.User;
import kz.bitlab.springboot.securitydemo.repositories.PermissionRepository;
import kz.bitlab.springboot.securitydemo.repositories.PostRepository;
import kz.bitlab.springboot.securitydemo.repositories.UserRepository;
import org.junit.jupiter.api.BeforeEach;
import org.junit.jupiter.api.Test;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.boot.webmvc.test.autoconfigure.AutoConfigureMockMvc;
import org.springframework.boot.test.context.SpringBootTest;
import org.springframework.security.crypto.password.PasswordEncoder;
import org.springframework.test.context.ActiveProfiles;
import org.springframework.test.web.servlet.MockMvc;
import org.springframework.transaction.annotation.Transactional;

@SpringBootTest
@AutoConfigureMockMvc
@ActiveProfiles("test")
@Transactional
class SecurityWebMvcIT {

	@Autowired
	private MockMvc mockMvc;

	@Autowired
	private UserRepository userRepository;

	@Autowired
	private PermissionRepository permissionRepository;

	@Autowired
	private PostRepository postRepository;

	@Autowired
	private PasswordEncoder passwordEncoder;

	@BeforeEach
	void seedUsers() {
		postRepository.deleteAll();
		userRepository.deleteAll();
		permissionRepository.deleteAll();

		Permission roleUser = permissionRepository.save(permission("ROLE_USER"));
		Permission roleManager = permissionRepository.save(permission("ROLE_MANAGER"));
		Permission roleAdmin = permissionRepository.save(permission("ROLE_ADMIN"));

		persistUser("user@example.com", "user123", "Demo User", List.of(roleUser));
		persistUser("manager@example.com", "manager123", "Demo Manager", List.of(roleUser, roleManager));
		persistUser("admin@example.com", "admin123", "Demo Admin", List.of(roleUser, roleManager, roleAdmin));
	}

	private static Permission permission(String code) {
		Permission p = new Permission();
		p.setPermission(code);
		return p;
	}

	private void persistUser(String email, String rawPassword, String fullName, List<Permission> roles) {
		User u = new User();
		u.setEmail(email);
		u.setPassword(passwordEncoder.encode(rawPassword));
		u.setFullName(fullName);
		u.setRoles(new ArrayList<>(roles));
		userRepository.save(u);
	}

	@Test
	void managerCannotAccessAdminUsersPage_privilegeEscalationBlocked() throws Exception {
		User manager = userRepository.findByEmail("manager@example.com");
		assertThat(manager).isNotNull();
		mockMvc.perform(get("/users").with(user(manager))).andExpect(status().isForbidden());
	}

	@Test
	void plainUserCannotAccessManagerPostsPage_privilegeEscalationBlocked() throws Exception {
		User plain = userRepository.findByEmail("user@example.com");
		mockMvc.perform(get("/posts").with(user(plain))).andExpect(status().isForbidden());
	}

	@Test
	void adminCanAccessUsersPage() throws Exception {
		User admin = userRepository.findByEmail("admin@example.com");
		mockMvc.perform(get("/users").with(user(admin))).andExpect(status().isOk());
	}

	@Test
	void managerCanAccessPostsPage() throws Exception {
		User manager = userRepository.findByEmail("manager@example.com");
		mockMvc.perform(get("/posts").with(user(manager))).andExpect(status().isOk());
	}

	@Test
	void stateChangingPasswordWithoutCsrfTokenIsRejected() throws Exception {
		User u = userRepository.findByEmail("user@example.com");
		mockMvc.perform(post("/save-password")
						.with(user(u))
						.param("user_old_password", "user123")
						.param("user_new_password", "newpass999")
						.param("user_repeat_new_password", "newpass999"))
				.andExpect(status().isForbidden());
	}

	@Test
	void stateChangingPasswordWithCsrfSucceeds() throws Exception {
		User u = userRepository.findByEmail("user@example.com");
		mockMvc.perform(post("/save-password")
						.with(user(u))
						.with(csrf())
						.param("user_old_password", "user123")
						.param("user_new_password", "Newpass888!!")
						.param("user_repeat_new_password", "Newpass888!!"))
				.andExpect(status().is3xxRedirection())
				.andExpect(redirectedUrl("/change-password?success"));
	}

	@Test
	void adminDeleteUserWithoutCsrfIsRejected() throws Exception {
		User admin = userRepository.findByEmail("admin@example.com");
		User victim = userRepository.findByEmail("user@example.com");
		mockMvc.perform(post("/users/{id}/delete", victim.getId()).with(user(admin)))
				.andExpect(status().isForbidden());
	}
}
